declare const initOverlayOnce: () => void;
export default initOverlayOnce;
